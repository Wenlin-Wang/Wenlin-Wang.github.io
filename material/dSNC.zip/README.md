## Deep Stochastic Neighbors Compression

Training a standard lenet5 with softmax:

``` th main.lua --dSNC 0 ``` 

Training our deep stochastic neighbors compression:

``` th main.lua --dSNC 1 ``` 
